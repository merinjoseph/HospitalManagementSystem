package com.cts.app.HospitalApplication.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookingAppointment {
	
	@Id
	private int patientId;
	private String patientName;
	private String specialistName;
	private String specialistType;
	private String appointmentDay;
	private String appointmentTime;
	private String appointmentStatus;
	public BookingAppointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookingAppointment(int patientId, String patientName, String specialistName, String specialistType,
			String appointmentDay, String appointmentTime, String appointmentStatus) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.specialistName = specialistName;
		this.specialistType = specialistType;
		this.appointmentDay = appointmentDay;
		this.appointmentTime = appointmentTime;
		this.appointmentStatus = appointmentStatus;
	}
	
	public BookingAppointment(String appointmentStatus)
	{
		this.appointmentStatus = appointmentStatus;
	}
	
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getSpecialistName() {
		return specialistName;
	}
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}
	public String getSpecialistType() {
		return specialistType;
	}
	public void setSpecialistType(String specialistType) {
		this.specialistType = specialistType;
	}
	public String getAppointmentDay() {
		return appointmentDay;
	}
	public void setAppointmentDay(String appointmentDay) {
		this.appointmentDay = appointmentDay;
	}
	public String getAppointmentTime() {
		return appointmentTime;
		
		
	}
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	public String getAppointmentStatus() {
		return appointmentStatus;
	}
	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}
	
	
}
