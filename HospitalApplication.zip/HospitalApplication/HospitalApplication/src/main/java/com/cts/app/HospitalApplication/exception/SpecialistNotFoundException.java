package com.cts.app.HospitalApplication.exception;

public class SpecialistNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SpecialistNotFoundException(String specialistType) {

        super(String.format("Specialist with this "+specialistType+ " type not found"));
    }

}
