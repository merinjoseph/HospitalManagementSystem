package com.example.servingwebcontent;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@XmlRootElement
public class SpecialistMapProp {

	@Value("${item.type0}") 
	private String type0;
	@Value("${item.name0}")
	private String name0;
	@Value("${item.availableDay0}")
	private String availableDay0;
	@Value("${item.availableTime0}")
	private String availableTime0;
	@Value("${item.available0}")
	private String available0 ;
	@Value("${item.hospitalId0}")
	private String hospitalId0;
	
	
	@Value("${item.type1}") 
	private String type1;
	@Value("${item.name1}")
	private String name1;
	@Value("${item.availableDay1}")
	private String availableDay1;
	@Value("${item.availableTime1}")
	private String availableTime1;
	@Value("${item.available1}")
	private String available1 ;
	@Value("${item.hospitalId1}")
	private String hospitalId1;
	
	private List<Item> lists;
	
	
	public String getType0() {
		return type0;
	}
	public void setType0(String type0) {
		this.type0 = type0;
	}
	public String getName0() {
		return name0;
	}
	public void setName0(String name0) {
		this.name0 = name0;
	}
	public String getAvailableDay0() {
		return availableDay0;
	}
	public void setAvailableDay0(String availableDay0) {
		this.availableDay0 = availableDay0;
	}
	public String getAvailableTime0() {
		return availableTime0;
	}
	public void setAvailableTime0(String availableTime0) {
		this.availableTime0 = availableTime0;
	}
	public String getAvailable0() {
		return available0;
	}
	public void setAvailable0(String available0) {
		this.available0 = available0;
	}
	public String getHospitalId0() {
		return hospitalId0;
	}
	public void setHospitalId0(String hospitalId0) {
		this.hospitalId0 = hospitalId0;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getAvailableDay1() {
		return availableDay1;
	}
	public void setAvailableDay1(String availableDay1) {
		this.availableDay1 = availableDay1;
	}
	public String getAvailableTime1() {
		return availableTime1;
	}
	public void setAvailableTime1(String availableTime1) {
		this.availableTime1 = availableTime1;
	}
	public String getAvailable1() {
		return available1;
	}
	public void setAvailable1(String available1) {
		this.available1 = available1;
	}
	public String getHospitalId1() {
		return hospitalId1;
	}
	public void setHospitalId1(String hospitalId1) {
		this.hospitalId1 = hospitalId1;
	}
	
	
	
	public List<Item> getLists() {
		setLists(lists);
		return lists;
	}
	public void setLists(List<Item> lists) {
		lists=new ArrayList<Item>();
		Item item=new Item(type0, name0,
				  availableDay0, availableTime0, available0, hospitalId0); 
		lists.add(item);
				  item=new Item(type1, name1, availableDay1, availableTime1, available1,
				  hospitalId1); 
				  lists.add(item);
				  

		
		this.lists = lists;
	}
	@Override
	public String toString() {
		
		  		 		return "SpecialistMapProp [type0=" + type0 + ", name0=" + name0 + ", availableDay0=" + availableDay0
				+ ", availableTime0=" + availableTime0 + ", available0=" + available0 + ", hospitalId0=" + hospitalId0
				+ ", type1=" + type1 + ", name1=" + name1 + ", availableDay1=" + availableDay1 + ", availableTime1="
				+ availableTime1 + ", available1=" + available1 + ", hospitalId1=" + hospitalId1 + "]";
	}
	
	
	
	
}
