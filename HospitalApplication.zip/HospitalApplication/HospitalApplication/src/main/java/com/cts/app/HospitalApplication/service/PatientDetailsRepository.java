package com.cts.app.HospitalApplication.service;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.app.HospitalApplication.entity.PatientDetails;

public interface PatientDetailsRepository extends JpaRepository<PatientDetails,Integer> {
	
	List<PatientDetails> findVacancyByHospitalName(String hospitalName);

}
