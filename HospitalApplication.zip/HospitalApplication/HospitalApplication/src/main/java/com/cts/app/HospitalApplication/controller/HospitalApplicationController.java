package com.cts.app.HospitalApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.app.HospitalApplication.entity.BookingAppointment;
import com.cts.app.HospitalApplication.entity.SpecialistDetails;
import com.cts.app.HospitalApplication.exception.AppointmentNotFoundException;
import com.cts.app.HospitalApplication.service.HospitalApplicationServiceImpl;



@RestController
public class HospitalApplicationController {
	

	int patientId = 1;
	
	@Autowired
	HospitalApplicationServiceImpl hospitalApplicationServiceImpl;
	
	@GetMapping(path = "/doctors")
	public List<SpecialistDetails> findDoctotrs(){
		
		List<SpecialistDetails> findDoctors = hospitalApplicationServiceImpl.findAllDoctors();
		return findDoctors;
	
	
}
	
	@GetMapping(path = "/doctors/{specialistType}")
	public List<SpecialistDetails> findSpecialistDetails(@PathVariable String specialistType) throws Exception {
		
		List<SpecialistDetails> findSpecialistDetails = hospitalApplicationServiceImpl.findSpecialistDetails(specialistType);
		return findSpecialistDetails;
	
	
}
	@GetMapping(path = "doctors/bookingAppointment/{specialistName}/{appointmentDay}/{patientName}")
	public BookingAppointment bookingAppointment(@PathVariable String specialistName,@PathVariable String appointmentDay,@PathVariable String patientName)
			throws Exception {
		
		String appointmentStatus=null;
		
		BookingAppointment appointmentDetails = new BookingAppointment();
		
		SpecialistDetails specialistDetails = hospitalApplicationServiceImpl.findSpecialistDetailsByName(specialistName);
		
		if(specialistDetails.getAvailableDay().contains(appointmentDay) && specialistDetails.getIsAvailable().contains("Y"))
		{
			appointmentStatus="Your Appointment is booked Successfully!" ;
			
			appointmentDetails.setAppointmentStatus(appointmentStatus);
			appointmentDetails.setPatientId(patientId);
			appointmentDetails.setPatientName(patientName);
			appointmentDetails.setAppointmentDay(appointmentDay);
			appointmentDetails.setSpecialistName(specialistName);
			appointmentDetails.setAppointmentTime(specialistDetails.getAvailableTime());
			appointmentDetails.setSpecialistType(specialistDetails.getSpecialistType());
	    	System.out.println("Patient Name - "+ appointmentDetails.getPatientName());
	    	System.out.println("Specialist Name - "+ appointmentDetails.getSpecialistName());
			
	    	
	         hospitalApplicationServiceImpl.saveAppointmentDetails(appointmentDetails);
	    	
	    	 patientId++;
	    	 
	    
	    	 
	    	 
				
		}
			
			else
			{
				appointmentStatus= " Sorry, Your requested specialist is not available on that day";
				throw new AppointmentNotFoundException(specialistName);
				//appointmentDetails.setAppointmentStatus(appointmentStatus);
				// return new BookingAppointment(appointmentDetails.getAppointmentStatus()); 
			}
		
		
		return new BookingAppointment(appointmentDetails.getPatientId(),appointmentDetails.getPatientName(),appointmentDetails.getSpecialistName(), 
				 appointmentDetails.getSpecialistType(),appointmentDetails.getAppointmentDay(),appointmentDetails.getAppointmentTime(),
				 appointmentDetails.getAppointmentStatus());    
		   
		
		
		
    	       
    	  }
	
	@GetMapping(path="/{hospitalName}")
	public int findVacancy(@PathVariable String hospitalName)
	{
		int vacancy = hospitalApplicationServiceImpl.findVacancyByHospitalName(hospitalName);
		
		System.out.println("Number of Bed Available - "+vacancy);
		
		return vacancy;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
   
	
}
