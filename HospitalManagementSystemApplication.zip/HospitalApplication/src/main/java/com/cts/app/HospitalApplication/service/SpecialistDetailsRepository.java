package com.cts.app.HospitalApplication.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.app.HospitalApplication.entity.SpecialistDetails;



public interface SpecialistDetailsRepository extends JpaRepository<SpecialistDetails,Integer>  {

	List<SpecialistDetails> findBySpecialistType(String specialistType);
	
	
	SpecialistDetails findBySpecialistName(String specialistName);
	
	
	
}
