package com.example.servingwebcontent;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;
@Component
@XmlRootElement
public class Lists {
	private List<Item> item;

	public List<Item> getLists() {
		return item;
	}

	public void setLists(List<Item> lists) {
		this.item = lists;
	}


}
