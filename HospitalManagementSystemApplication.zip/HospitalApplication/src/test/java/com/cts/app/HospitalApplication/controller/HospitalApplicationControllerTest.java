package com.cts.app.HospitalApplication.controller;



import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.cts.app.HospitalApplication.HospitalApplication;
import com.cts.app.HospitalApplication.entity.SpecialistDetails;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = HospitalApplication.class,
		webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HospitalApplicationControllerTest {
	
	@LocalServerPort
	private int port;
	@SuppressWarnings("unlikely-arg-type")
	@Test
	public void retrieveSpecialistDetails()  throws Exception {
		String url = "http://localhost:" + port + "/doctors/Neuro";	
		TestRestTemplate restTemplate = new TestRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		SpecialistDetails specialistDetails = new SpecialistDetails();
		ResponseEntity<List<SpecialistDetails>> response = restTemplate.exchange(url,
				HttpMethod.GET, new HttpEntity<SpecialistDetails>(specialistDetails,
						headers),
				new ParameterizedTypeReference<List<SpecialistDetails>>() {
				});
		
		SpecialistDetails sampleSpecialistDetails = new SpecialistDetails(1,108,"5 to 6 PM","Monday,Wednesday","SIMS","Y","Surya","Neuro");

		equals(response.getBody().contains(sampleSpecialistDetails));
	}

	
	

}
