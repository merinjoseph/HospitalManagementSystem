package com.cts.app.HospitalApplication.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SpecialistDetails {
	
	@Id
	private int specialistId;
    private int hospitalId;
    private String hospitalName;
    private String specialistName;
    private String specialistType;
    private String availableDay;
    private String availableTime;
    private String isAvailable;
    
    public SpecialistDetails(int specialistId, int hospitalId, String hospitalName, String specialistName,
			String specialistType, String availableDay, String availableTime, String isAvailable) {
		super();
		this.specialistId = specialistId;
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.specialistName = specialistName;
		this.specialistType = specialistType;
		this.availableDay = availableDay;
		this.availableTime = availableTime;
		this.isAvailable = isAvailable;
	}
	public SpecialistDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getSpecialistId() {
		return specialistId;
	}
	public void setSpecialistId(int specialistId) {
		this.specialistId = specialistId;
	}
	public int getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getSpecialistName() {
		return specialistName;
	}
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}
	public String getSpecialistType() {
		return specialistType;
	}
	public void setSpecialistType(String specialistType) {
		this.specialistType = specialistType;
	}
	public String getAvailableDay() {
		return availableDay;
	}
	public void setAvailableDay(String availableDay) {
		this.availableDay = availableDay;
	}
	public String getAvailableTime() {
		return availableTime;
	}
	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	

	
}
