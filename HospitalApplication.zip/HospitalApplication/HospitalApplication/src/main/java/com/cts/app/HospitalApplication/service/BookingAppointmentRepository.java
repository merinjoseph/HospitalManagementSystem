package com.cts.app.HospitalApplication.service;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.app.HospitalApplication.entity.BookingAppointment;




public interface BookingAppointmentRepository  extends JpaRepository<BookingAppointment,Integer>  {
	
	
}
