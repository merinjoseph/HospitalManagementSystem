package com.cts.app.HospitalApplication.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PatientDetails {
	
    @Id
	private int patiendId;
    private String hospitalName;
    private String patientName;
    private String patientStatus;
	public PatientDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PatientDetails(int patiendId, String hospitalName, String patientName, String patientStatus) {
		super();
		this.patiendId = patiendId;
		this.hospitalName = hospitalName;
		this.patientName = patientName;
		this.patientStatus = patientStatus;
	}
	public int getPatiendId() {
		return patiendId;
	}
	public void setPatiendId(int patiendId) {
		this.patiendId = patiendId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientStatus() {
		return patientStatus;
	}
	public void setPatientStatus(String patientStatus) {
		this.patientStatus = patientStatus;
	}
	
    
    

}
