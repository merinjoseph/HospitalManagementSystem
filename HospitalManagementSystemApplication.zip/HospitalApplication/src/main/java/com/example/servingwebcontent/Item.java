package com.example.servingwebcontent;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@XmlRootElement
//@ConfigurationProperties("application")
@ConfigurationProperties(prefix = "specialist") 
public class Item {

	private String type;
	private String name;
	private String availableDay;
	private String availableTime;
	private String available ;
	private String hospitalId;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAvailableDay() {
		return availableDay;
	}
	public void setAvailableDay(String availableDay) {
		this.availableDay = availableDay;
	}
	public String getAvailableTime() {
		return availableTime;
	}
	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}
	public String getAvailable() {
		return available;
	}
	public void setAvailable(String available) {
		this.available = available;
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public Item() {
		
	}
	public Item(String type, String name, String availableDay, String availableTime, String available,
			String hospitalId) {
		super();
		this.type = type;
		this.name = name;
		this.availableDay = availableDay;
		this.availableTime = availableTime;
		this.available = available;
		this.hospitalId = hospitalId;
	}
	@Override
	public String toString() {
		return "Item [type=" + type + ", name=" + name + ", availableDay=" + availableDay + ", availableTime="
				+ availableTime + ", available=" + available + ", hospitalId=" + hospitalId + "]";
	}
	
	
	
	
}
