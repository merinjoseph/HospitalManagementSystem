package com.cts.app.HospitalApplication.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.app.HospitalApplication.entity.BookingAppointment;
import com.cts.app.HospitalApplication.entity.PatientDetails;
import com.cts.app.HospitalApplication.entity.SpecialistDetails;
import com.cts.app.HospitalApplication.exception.SpecialistNotFoundException;




@Service
public class HospitalApplicationServiceImpl
{
	
	

	@Autowired
	private SpecialistDetailsRepository specialistDetailsRepository;
	
	@Autowired
	private BookingAppointmentRepository bookingAppointmentRepository;
	
	@Autowired
	private PatientDetailsRepository patientDetailsRepository;
	
	
	public List<SpecialistDetails> findAllDoctors()
	{
		return specialistDetailsRepository.findAll();
	}
	
	public List<SpecialistDetails> findSpecialistDetails(String specialistType)
	{
		List<SpecialistDetails> findDoctorsByType = specialistDetailsRepository.findBySpecialistType(specialistType);
		
		if(findDoctorsByType.size() == 0)
		{
			throw new SpecialistNotFoundException(specialistType);
		}
		return findDoctorsByType;
	}

	public SpecialistDetails findSpecialistDetailsByName(String specialistName)
	{
		return specialistDetailsRepository.findBySpecialistName(specialistName);
	}
	
	public void saveAppointmentDetails(BookingAppointment bookingappointment)
	{
		bookingAppointmentRepository.save(bookingappointment);
	}

	public int findVacancyByHospitalName(String hospitalName) 
	{
		
		int vacancy=0;
		
		//List<PatientDetails> patientDetails = patientDetailsRepository.findAll();
		
		List<PatientDetails> patientDetails = patientDetailsRepository.findVacancyByHospitalName(hospitalName);
		
		
		Iterator<PatientDetails> iterator = patientDetails.iterator();
		while(iterator.hasNext())
		{
			PatientDetails pd = iterator.next();
			
			if(pd.getPatientStatus().equals("DISCHARGE"))
			{
				vacancy++;
			}
			
		}
		
		//String st = "Number of Beds Available = "+Integer.toString(vacancy);
		return vacancy;
	}

	

	
}
