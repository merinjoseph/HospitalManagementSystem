package com.example.servingwebcontent;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FrontDeskController {
	
	@Autowired
	private SpecialistMapProp specilistProp;
	private Item item;
	@RequestMapping(value = "/doctorsList", method = RequestMethod.GET,
			produces = { "application/json", "application/xml" })
	@Cacheable("lists")
	public Lists firstPage(@RequestParam(name="mediaType", defaultValue = "json")String mediaType ) {
		
		  //item =new Item(); item.setName("jjjj");
		 
		System.out.println(specilistProp);
		Lists ls=new Lists();
		ls.setLists(specilistProp.getLists());
		return ls;
	}
	
	@RequestMapping(value = "/specialist", method = RequestMethod.GET,
			produces = { "application/json", "application/xml" })
	@Cacheable("lists")
	public ResponseEntity<Object > getSpecialist(@RequestParam(name="mediaType", defaultValue = "json") String mediaType,
			@RequestParam("type") String type,@RequestParam("hospitalId") String hospilalId) {
		
		 
		System.out.println(specilistProp);
		Lists ls=new Lists();
		List<Item> l=new ArrayList<Item>();
		
		for (Item u : specilistProp.getLists()) {
            if (u != null && u.getType().toString().equalsIgnoreCase(type.toString()) && u.getHospitalId().toString().equalsIgnoreCase(hospilalId.toString())) {
            	l.add(u);
            }else {
            	throw new ResourceNotFoundException("details found with type = " + type + "  HospitalId = " + hospilalId);
            }
               
        }
		
		return new ResponseEntity<>( l,HttpStatus.OK);
	}
}
