package com.cts.app.HospitalApplication.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Speciallists {
	private List<SpecialistDetails> findSpecialistDetails;

	public List<SpecialistDetails> getFindSpecialistDetails() {
		return findSpecialistDetails;
	}

	public void setFindSpecialistDetails(List<SpecialistDetails> findSpecialistDetails) {
		this.findSpecialistDetails = findSpecialistDetails;
	}
	
	
}
