package com.cts.app.HospitalApplication.exception;

public class AppointmentNotFoundException extends RuntimeException{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AppointmentNotFoundException(String specialistName) {

        super(String.format("Sorry your appointment is not available for this Specialist! " +specialistName + " Please try some other specialist or day!"));
    }

}
