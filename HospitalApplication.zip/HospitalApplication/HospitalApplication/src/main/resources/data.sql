INSERT INTO Specialist_details VALUES(1,'Monday,Wednesday','5 to 6 PM',108,'SIMS','Y','Surya','Neuro');
INSERT INTO Specialist_details VALUES(2,'Tuesday,Thursday','9 to 11 AM',108,'SIMS','N','Sandhya','Neuro');
INSERT INTO Specialist_details VALUES(3,'Friday,Sunday','2 to 4 PM ',108,'SIMS','Y','Balaji','Neuro');
INSERT INTO Specialist_details VALUES(4,'Monday,Wednesday','5 to 6 PM',108,'SIMS','N','Suresh','Dentist');
INSERT INTO Specialist_details VALUES(5,'Tuesday,Thursday','9 to 11 AM',108,'SIMS','Y','Varshini','Dentist');
INSERT INTO Specialist_details VALUES(6,'Friday,Sunday','12 to 2 PM ',108,'SIMS','N','Kanth','Dentist');
INSERT INTO Specialist_details VALUES(7,'Monday,Wednesday','5 to 6 PM',108,'SIMS','Y','Vamsi','Ortho');
INSERT INTO Specialist_details VALUES(8,'Tuesday,Thursday','9 to 11 AM',108,'SIMS','N','Aditya','Ortho');
INSERT INTO Specialist_details VALUES(9,'Friday,Sunday','12 to 2 PM ',108,'SIMS','Y','Laxmi','Ortho');
INSERT INTO Specialist_details VALUES(10,'Tuesday,Thursday','9 to 11 AM',911,'Apollo','N','Umesh','OBGYN');
INSERT INTO Specialist_details VALUES(11,'Friday,Sunday','12 to 2 PM ',911,'Apollo','Y','Mala','OBGYN');

--INSERT INTO Specialist_details VALUES(1,'Monday','5 to 6 PM',108,'SIMS','Y','Surya','Neuro');
--INSERT INTO Specialist_details VALUES(2,'Tuesday','9 to 11 AM',108,'SIMS','N','Sandhya','Neuro');
--INSERT INTO Specialist_details VALUES(3,'Friday','2 to 2 PM ',108,'SIMS','Y','Balaji','Neuro');
--INSERT INTO Specialist_details VALUES(4,'Monday','5 to 6 PM',108,'SIMS','N','Suresh','Dentist');
--INSERT INTO Specialist_details VALUES(5,'Tuesday','9 to 11 AM',108,'SIMS','Y','Varshini','Dentist');
--INSERT INTO Specialist_details VALUES(6,'Friday','12 to 2 PM ',108,'SIMS','N','Kanth','Dentist');
--INSERT INTO Specialist_details VALUES(7,'Monday','5 to 6 PM',108,'SIMS','Y','Vamsi','Ortho');
--INSERT INTO Specialist_details VALUES(8,'Tuesday','9 to 11 AM',108,'SIMS','N','Aditya','Ortho');
--INSERT INTO Specialist_details VALUES(9,'Friday','12 to 2 PM ',108,'SIMS','Y','Laxmi','Ortho');
--INSERT INTO Specialist_details VALUES(10,'Tuesday','9 to 11 AM',911,'Apollo','N','Umesh','OBGYN');
--INSERT INTO Specialist_details VALUES(11,'Friday','12 to 2 PM ',91,'Apollo','Y','Mala','OBGYN');





INSERT INTO patient_details VALUES(1,'SIMS','Kannan','UNDER TREATMENT');
INSERT INTO patient_details VALUES(2,'SIMS','Rajesh','DISCHARGE');
INSERT INTO patient_details VALUES(3,'SIMS','Varshini','DISCHARGE');
INSERT INTO patient_details VALUES(4,'SIMS','Karthik','DISCHARGE');
INSERT INTO patient_details VALUES(5,'SIMS','Simran','DISCHARGE');
INSERT INTO patient_details VALUES(6,'Apllo','Anand','UNDER TREATMENT');
INSERT INTO patient_details VALUES(7,'Apollo','Selva','UNDER TREATMENT');
INSERT INTO patient_details VALUES(8,'Apollo','Nilesh','DISCHARGE');
INSERT INTO patient_details VALUES(9,'Apollo','Suraj','DISCHARGE');
INSERT INTO patient_details VALUES(10,'Apollo','Marco','DISCHARGE');